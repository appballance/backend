=============================
 Polyfill for Flake8 Plugins
=============================

``flake8-polyfill`` is a package that provides some compatibility helpers for
Flake8 plugins that intend to support Flake8 2.x and 3.x simultaneously.


Installation
============

.. code-block:: bash

    pip install flake8-polyfill


Usage
=====

Option Handling
---------------

One problem area with compatibility with Flake8 2.x and 3.x is the registering
options and receiving the parsed values.

Flake8 3.0 added extra parameters to the ``add_option`` method which don't
have the same effect on Flake8 2.x. To accomodate the change, this polyfill
module allows you to do:

.. code-block:: python

    from flake8_polyfill import options

    class MyFlake8Plugin(object):
        @classmethod
        def add_options(cls, parser):
            options.register(parser, '--my-long-option-name',
                             parse_from_config=True,
                             comma_separated_list=True,
                             default='...',
                             help='...')
            options.register(parser, '-m', '--my-other-long-option-name',
                             parse_from_config=True,
                             normalize_paths=True,
                             default='...',
                             help='...')

        @classmethod
        def parse_options(cls, values):
            cls.my_long_option_name = values.my_long_option_name
            cls.my_other_long_option_name = values.my_other_long_option_name

And have the code work the same way on both versions.

Retrieving Standard In
----------------------

Until Flake8 2.6, getting the code on standard in from a plugin has been
simple:

.. code-block:: python

    import pep8

    stdin = pep8.get_stdin_value()

In 2.6 you now have to know whether to use ``pep8`` or ``pycodestyle`` since
Flake8 2.6 made a hard change to ``pycodestyle``.

The reason you need to know which module to use is because standard in can be
exhausted and Flake8 does some work to cache the value so that call always
returns the desired data.

In 3.0, Flake8 no longer monkey-patches those modules.

To accommodate this, this package provides:

.. code-block:: python

    from flake8_polyfill import stdin

    stdin.monkey_patch('all')
    stdin.monkey_patch('pep8')
    stdin.monkey_patch('pycodestyle')

This allows you to have the polyfill module monkey-patch what you want so it
is always monkey-patched. It will also do so in an intelligent way.

Version Comparison
------------------

Flake8 2.x did not include an object that would allow for easy version
comparison. Flake8 3.0, however, added a ``__version_info__`` attribute. For
consistency, Flake8 Polyfill will turn 2.x's version string into a tuple
suitable for comparison.

.. code-block:: python

    from flake8_polyfill import version

    if (2, 4) <= version.version_info < (2, 6):
        # ...
    elif (2, 6) <= version.version_info < (3, 0):
        # ...
    elif (3, 0) <= version.version_info < (4, 0):
        # ...


License
=======

MIT


Creator
=======

Ian Cordasco


